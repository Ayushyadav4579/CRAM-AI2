# CRAM AI

CRAM AI is a mobile-friendly AI study workspace that turns a student's own PDFs and notes into a complete learning system.

## Included

- PDF, DOCX, TXT and Markdown upload
- Paste notes
- Automatic topic detection
- AI-generated detailed and quick revision notes
- AI MCQs and exam questions
- AI mixed quiz
- Mnemonics and memory tricks for difficult facts
- Flashcards, fill-in-the-blanks, true/false, mind maps, definitions and formulas
- Ask your notes with a source-grounded AI tutor
- Local study history
- Copy and download study systems
- Secure server-side Gemini API integration
- Netlify Functions backend
- Security headers, origin protection and basic rate limiting
- Responsive mobile-first interface

## AI setup

Set `GEMINI_API_KEY` in Netlify environment variables. Never put the key in frontend code.

Optional: `GEMINI_MODEL` and `SITE_URL`.

## Deploy to Netlify

The included `netlify.toml` contains the build and direct `/api/*` Netlify Function configuration. PDF/DOCX uploads are limited to 4 MB on Netlify; TXT/MD files are read in the browser. See `NETLIFY_DEPLOY.md` for the complete steps.

## Subscription

This release intentionally contains **no fake/demo Pro subscription UI**. Real paid plans can be integrated later with a payment provider and server-side verification.


## Netlify OCR support

CRAM AI now supports OCR for scanned/image-only PDFs and JPG/PNG study images. Normal text PDFs are parsed locally first; when a PDF has no readable text, the server uses the configured Gemini model's multimodal input to extract the visible text. JPG/PNG uploads are OCR'd through the same server-side Gemini API key.

The OCR path requires `GEMINI_API_KEY` in Netlify Environment Variables and respects the 4 MB upload limit.
