# CRAM AI — Netlify deployment

## 1. Deploy

1. Extract this ZIP.
2. Upload the project to a GitHub repository.
3. In Netlify, import that repository.
4. Build command: `pnpm run build`
5. Publish directory: `artifacts/cram-ai/dist/public`
6. Node: `22`
7. PNPM: `10.12.1`

The included `netlify.toml` already contains these settings, so Netlify normally detects them automatically.

## 2. Required environment variable

Add this in Netlify → Project configuration → Environment variables:

`GEMINI_API_KEY` = your Google Gemini API key

Optional:

`GEMINI_MODEL` = `gemini-2.5-flash`

`SITE_URL` = your deployed Netlify site URL, for example `https://your-site.netlify.app`

The Gemini key is used only inside the Netlify Function. It is never placed in the browser bundle.

## 3. Features

- PDF, DOCX, TXT and Markdown upload
- Paste notes
- Automatic topic detection
- AI study notes and revision material
- AI MCQs and exam questions
- AI mixed quiz
- Mnemonics and memory tricks
- Flashcards, fill blanks, true/false and more
- Ask your notes / source-grounded AI tutor
- Local study history
- Copy and download generated study systems
- Mobile responsive UI
- Netlify Function backend
- Security headers, same-origin protection and basic rate limiting

## 4. Important

The app does not contain a fake/demo Pro subscription. There is no payment UI in this version.

Real paid subscriptions can be added later with a payment provider and server-side verification if needed.

Scanned/image-only PDFs need OCR because the current extractor reads embedded PDF text.
