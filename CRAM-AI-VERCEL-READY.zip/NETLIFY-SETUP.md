# CRAM AI — Netlify deployment

## Deploy from GitHub (recommended)
1. Upload this entire project folder to a GitHub repository.
2. In Netlify, choose **Add new project → Import an existing project**.
3. Select the GitHub repository.
4. Netlify will use the included `netlify.toml` automatically.
5. Deploy.

The frontend build is configured to use:
- Build command: `pnpm --filter @workspace/cram-ai build`
- Publish directory: `artifacts/cram-ai/dist/public`

## AI/API backend
The AI and document endpoints are included as a Netlify Function at `/api/*`; no separate Express server is required. The function reads `GEMINI_API_KEY` only on the server.

The function is routed directly with Netlify's function path configuration, so the API requests do not depend on an extra `/api/*` rewrite. This is important for longer Gemini requests because Netlify rewrite/proxy requests have a shorter timeout than direct function invocations.

PDF/DOCX uploads are limited to 4 MB on this Netlify deployment. TXT/MD files are read directly in the browser, so they do not use the upload endpoint.

## Pro subscriptions
The Pro UI in this project is a frontend/demo subscription state. Real ₹149/month or ₹999/year payments require a payment provider and server-side payment verification.


## PDF extraction fix
The Netlify function uses the stable Node-compatible `pdf-parse` 1.1.4 path already used by the project's API server. This avoids the v2 worker/native-canvas packaging problems that can cause serverless 502 errors. Scanned/image-only PDFs still require OCR.

After changing environment variables or code, trigger a fresh production deploy.
